CLOSET BUDDY — WORKING WEB APP PROTOTYPE

OPEN LOCALLY
1. Unzip the folder.
2. Double-click index.html to open it in Chrome or Edge.
3. Go to My Wardrobe, add clothing item names/categories and optionally upload photos.
4. Open Create to select occasion, mood and weather and generate an outfit.
5. Save a look; under Saved Looks, assign it to a day of the week.
6. See planned outfits in Planner.
7. In Saved Looks, Export backup regularly; Import backup to restore your data.

PUBLISH ONLINE (GITHUB PAGES)
1. Create a free account at github.com and a new public repository named closet-buddy.
2. Upload index.html to the root of the repository and commit.
3. Go to Settings > Pages > Build and deployment.
4. Choose Deploy from a branch, branch main, folder /(root), and Save.
5. After deployment, GitHub Pages will show the public URL (usually https://YOURUSERNAME.github.io/closet-buddy/).
6. To update the app, edit/replace index.html in your GitHub repository and commit.

ALTERNATIVE: NETLIFY DROP
1. Sign in to app.netlify.com.
2. Choose the manual deploy/drop option and upload the unzipped closet_buddy_app folder.
3. Netlify provides a public URL. Re-deploy the folder to update it.

IMPORTANT LIMITATIONS
- This is a working browser-based demo, NOT an Android APK or a hosted AI service.
- Outfit suggestions are simple rule-based combinations from your uploaded items, not a live AI model.
- Photos, wardrobe and saved outfits use browser localStorage and are specific to each browser/device. They are not synced to the cloud.
- Clearing browser storage or using a different device can erase your data. Export a backup often.
- Photos are resized to reduce storage, but browser storage can still fill up.
- Weather is selected manually, not pulled from a weather service.
- No accounts, backend, shared data, payment features, or real app-store listing.
